---
name: Feature request
about: Suggest an idea for this project

---

**What mechanics does this feature affect?**
<!-- Player, Web-sockets, Items, UI, Map, Database -->

**How hard would it be to implement this feature on a scale of 1-10 (10 = hardest)?**

**What is the feature request?**
