import player from './players';
/**
 * Pipelines are used to handle
 * events for certain actions
 */
export default {
  player,
};
