<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Objects" tilewidth="32" tileheight="32" tilecount="288" columns="9">
 <image source="../../../src/assets/tiles/objects.png" width="288" height="1024"/>
</tileset>
