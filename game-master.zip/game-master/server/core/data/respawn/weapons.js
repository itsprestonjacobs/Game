export default [{
  id: 'bronze-pickaxe',
  respawnIn: '8s',
  x: 20,
  y: 112,
}];
