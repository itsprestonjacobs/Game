### Opening `.xcf` files

These `.xcf` files are opened using GIMP.

### What is GIMP?

https://www.gimp.org/

GIMP is a free and open-source raster graphics editor used for image retouching and editing, free-form drawing, converting between different image formats, and more specialized tasks. GIMP is released under GPLv3+ licenses and is available for Linux, macOS, and Microsoft Windows.

It's also free.